# AniKatsu API

### Installing

Clone the Repository and run


```
git clone https://github.com/shashankktiwariii/anikatsu-api.git
cd anikatsu-api
npm install 
```
start the server with the following command:
```
npm start
```

Now the server is running on <a href="http://localhost:3000">http://localhost:3000</a>
